class MiClase {
const constante = 'valor constante';
function mostrarConstante() {
echo self::constante . "\n";
}
}