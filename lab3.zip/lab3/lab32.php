<?php
$preciol = $_POST['precio1'];
$precio2 = $_POST['precio2'];
$precio3 = $_POST['precio3'];
$media ($preciol $precio2+$precio3)/3;
echo "<br/> DATOS RECIBIDOS";
echo "<br/> El precio producto establecimiento 1" $preciol. "dolares";
echo "<br/> El precio producto establecimiento 2": $precio2. "dolares";
echo "<br/> El precio producto establecimiento 3": Sprecio3. "dolares";
echo "<br/> El precio medio del producto es de" . $media. "dolares <br/>";
?>