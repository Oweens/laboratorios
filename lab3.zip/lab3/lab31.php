<?php
$diametro = $_POST['diam'];
Saltura = $_POST['altu'];
$radio= $diametro/2;
$Pi = 3.141593;
$volumen= $Pi*Sradio*$radio*$altura;
echo "<br/> El volumen del cilindro es de ". $volumen. "metros cubicos";
?>