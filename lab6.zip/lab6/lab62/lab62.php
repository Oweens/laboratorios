<?php
include("class_lib.php");
//instaciamos un par de objetos clientes
$cliente1 =new clientes("Pepe", 1);
$cliente2 =new clientes("Roberto", 564);

//mostramos el numero de cada cliente creado
echo "<br> El indeficador del clientes 1  es:" . $cliente1->dame_numero();
echo "<br> El indeficador del clientes 2  es:" . $cliente2->dame_numero();
?>